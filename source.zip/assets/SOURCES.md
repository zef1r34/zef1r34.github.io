# Asset sources

- 7.css 0.21.1 — https://github.com/khang-nd/7.css (MIT; license included).
- Windows 7 wallpaper and icon resources — https://github.com/bartekl1/windows-ui-assets. Original Windows resources and trademarks belong to Microsoft.
- Resume PDFs — supplied candidate information, created for Yaroslav Beloglazov.
# Дополнения версии 2

Иконки browser.svg, paint.svg, user.svg и tasks.svg нарисованы в SVG для этого проекта. Новые приложения и оформление реализованы кодом HTML/CSS/JavaScript.

