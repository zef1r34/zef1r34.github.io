# Asset sources

- 7.css 0.21.1 — https://github.com/khang-nd/7.css (MIT; license included).
- Windows 7 wallpaper and icon resources — https://github.com/bartekl1/windows-ui-assets. Original Windows resources and trademarks belong to Microsoft.
- Resume PDFs — supplied candidate information, created for Yaroslav Beloglazov.
# Дополнения версии 2

Иконки browser.svg, paint.svg, user.svg и tasks.svg нарисованы в SVG для этого проекта. Новые приложения и оформление реализованы кодом HTML/CSS/JavaScript.

# Дополнения версии 3

- Three.js 0.180.0 (MIT): https://github.com/mrdoob/three.js/tree/r180. Лицензия: `vendor/three-LICENSE.txt`. Используются OrbitControls, STLLoader, OBJLoader, ThreeMFLoader и fflate из пакета Three.js; текст лицензии fflate сохранён в собранном runtime.
- occt-import-js 0.0.23 (LGPL-2.1): https://github.com/kovacsv/occt-import-js. Неизменённые JS/WASM получены из официального npm-пакета; лицензия: `vendor/occt-LICENSE.md`. Исходный CAD-движок Open CASCADE: https://github.com/Open-Cascade-SAS/OCCT; точная версия подмодуля указана в репозитории occt-import-js.
- Обои cat.svg, duck.svg, spacecat.svg, запасная SVG-анимация розыгрыша и интерфейсы приложений созданы кодом для этого проекта.
- Рикролл использует официальный видеоплеер YouTube, идентификатор dQw4w9WgXc. Видео не скачивается и не хранится в проекте. https://www.youtube.com/watch?v=dQw4w9WgXc

