import fs from 'node:fs/promises';
import path from 'node:path';
import zlib from 'node:zlib';
import {Script} from 'node:vm';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const out=path.join(root,'dist');
await fs.mkdir(out,{recursive:true});
const mime={'.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.pdf':'application/pdf'};
const assetData={};
async function gather(dir){for(const entry of await fs.readdir(dir,{withFileTypes:true})){const absolute=path.join(dir,entry.name);if(entry.isDirectory())await gather(absolute);else if(mime[path.extname(entry.name)]){const name=path.relative(root,absolute).split(path.sep).join('/');assetData[name]=`data:${mime[path.extname(entry.name)]};base64,${(await fs.readFile(absolute)).toString('base64')}`;}}}
await gather(path.join(root,'assets'));
const read=name=>fs.readFile(path.join(root,name),'utf8');
function rewriteAssetURLs(text){return text.replace(/\.\/assets\/[A-Za-z0-9_./-]+/g,original=>{const key=original.slice(2);return assetData[key]||original;});}
const css=rewriteAssetURLs((await read('style.css')).replaceAll("url('./assets/wallpapers/windows7.jpg')",'var(--portfolio-wallpaper)'));
const enhancements=await read('enhancements.css');
const studioCSS=await read('studio.css');
const studioJS=await read('studio.js');
const systemCSS=await read('system.css');
const systemJS=await read('system.js');
const vendor=await read('assets/vendor/7.css');
let app=await read('app.js');
const replacements=[
  ['const asset = name => `./assets/${name}`;','const asset = name => portfolioAsset(`assets/${name}`);']
];
for(const [before,after] of replacements){if(!app.includes(before))throw Error('Expected asset reference not found: '+before);app=app.replace(before,after);}
const features=(await read('features.js')).replace('const releaseFile = name => `./dist/${name}`;','const releaseFile = name => `./${name}`;');
const bootstrap=`const portfolioAssetData=${JSON.stringify(assetData)};\nconst portfolioAssetCache=new Map();\nfunction portfolioBlobURL(data){const [header,base64]=data.split(',');const bytes=Uint8Array.from(atob(base64),c=>c.charCodeAt(0));return URL.createObjectURL(new Blob([bytes],{type:header.slice(5,header.indexOf(';'))}));}\nfunction portfolioAsset(name){const data=portfolioAssetData[name];if(!data)throw Error('Missing portfolio asset: '+name);if(!name.endsWith('.pdf'))return data;if(!portfolioAssetCache.has(name))portfolioAssetCache.set(name,portfolioBlobURL(data));return portfolioAssetCache.get(name);}\ndocument.documentElement.style.setProperty('--portfolio-wallpaper','url("'+portfolioAsset('assets/wallpapers/windows7.jpg')+'")');\nfor(const link of document.querySelectorAll('a[href^="data:application/pdf;"]'))link.href=portfolioBlobURL(link.getAttribute('href'));\n`;
let html=await read('index.html');
html=html.replace('<link rel="stylesheet" href="./assets/vendor/7.css">',`<style>\n${vendor}\n</style>`)
  .replace('<link rel="stylesheet" href="./style.css">',`<style>\n${css}\n</style>`)
  .replace('<link rel="stylesheet" href="./enhancements.css">',()=>`<style>\n${enhancements}\n</style>`)
  .replace('<link rel="stylesheet" href="./studio.css">',()=>`<style>\n${studioCSS}\n</style>`)
  .replace('<link rel="stylesheet" href="./system.css">',()=>`<style>\n${systemCSS}\n</style>`)
  .replace('<script src="./studio.js" defer></script>','')
  .replace('<script src="./system.js" defer></script>','')
  .replace('<script src="./features.js" defer></script>','')
  .replace('<script src="./app.js" defer></script>','');
html=rewriteAssetURLs(html);
html=html.replace('</body>',()=>`<script>\n${bootstrap}\n${studioJS}\n${systemJS}\n${features}\n${app}\n</script>\n</body>`);
for(const [index,match] of [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].entries())new Script(match[1],{filename:`production-script-${index}.js`});
await fs.writeFile(path.join(out,'index.html'),html);
await fs.writeFile(path.join(out,'.nojekyll'),'');
await fs.writeFile(path.join(out,'viewer-runtime.js'),(await read('viewer-runtime.js')).replace('./assets/vendor/cad-worker.js','./cad-worker.js'));
for(const name of ['cad-worker.js','occt-import-js.js','occt-import-js.wasm'])await fs.copyFile(path.join(root,'assets/vendor',name),path.join(out,name));
await fs.writeFile(path.join(out,'README.md'),`# Портфолио Ярослава Белоглазова\n\nСайт: https://zef1r34.github.io/\n\nИнтерактивный рабочий стол в стиле Windows 7: перетаскивание ярлыков, Проводник с меню файлов, свойства проектов, окно для работодателя, Internet Explorer, Paint и диспетчер задач. Также доступны Блокнот, PDF-резюме, пошаговый помощник баг-репортов, калькулятор по данным слайсера и 3D-просмотрщик STL, OBJ, 3MF и STEP/STP. В панели управления есть звук, дата, обои и шуточная диагностика сети.\n\nОсновная оболочка и мини-приложения встроены в index.html. Трёхмерный просмотрщик использует отдельные JS/WASM-файлы из этого же репозитория. Редактируемые исходники — в source.zip.\n\nДля локального просмотра распакуйте исходники и выполните node server.mjs. Для обновления сборки выполните node build.mjs и загрузите все восемь файлов из dist в корень этого репозитория. 3D-runtime и CAD-модуль загружаются отдельно по необходимости.\n\nСоздано с помощью ИИ под руководством Ярослава. Используется 7.css (MIT); лицензия и сведения о Windows-ресурсах включены в архив исходников.\n`);

// ZIP archive with original editable files. Never include local credentials or generated output.
const crcTable=Array.from({length:256},(_,value)=>{let c=value;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function crc32(bytes){let c=0xffffffff;for(const value of bytes)c=crcTable[(c^value)&255]^(c>>>8);return(c^0xffffffff)>>>0;}
const sourceFiles=[];
async function collect(dir){for(const e of await fs.readdir(dir,{withFileTypes:true})){if(['dist','.git','node_modules','.preview'].includes(e.name)||e.name.startsWith('.env')||e.name.endsWith('.log'))continue;const absolute=path.join(dir,e.name);if(e.isDirectory())await collect(absolute);else sourceFiles.push({name:path.relative(root,absolute).split(path.sep).join('/'),data:await fs.readFile(absolute)});}}
await collect(root);
const localParts=[],centralParts=[];let offset=0;
const now=new Date();const dosTime=(now.getHours()<<11)|(now.getMinutes()<<5)|(now.getSeconds()>>1);const dosDate=((now.getFullYear()-1980)<<9)|((now.getMonth()+1)<<5)|now.getDate();
for(const file of sourceFiles){const name=Buffer.from(file.name);const data=zlib.deflateRawSync(file.data);const crc=crc32(file.data);const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50,0);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt16LE(dosTime,10);local.writeUInt16LE(dosDate,12);local.writeUInt32LE(crc,14);local.writeUInt32LE(data.length,18);local.writeUInt32LE(file.data.length,22);local.writeUInt16LE(name.length,26);localParts.push(local,name,data);const central=Buffer.alloc(46);central.writeUInt32LE(0x02014b50,0);central.writeUInt16LE(20,4);central.writeUInt16LE(20,6);central.writeUInt16LE(0x800,8);central.writeUInt16LE(8,10);central.writeUInt16LE(dosTime,12);central.writeUInt16LE(dosDate,14);central.writeUInt32LE(crc,16);central.writeUInt32LE(data.length,20);central.writeUInt32LE(file.data.length,24);central.writeUInt16LE(name.length,28);central.writeUInt32LE(offset,42);centralParts.push(central,name);offset+=local.length+name.length+data.length;}
const central=Buffer.concat(centralParts),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(sourceFiles.length,8);end.writeUInt16LE(sourceFiles.length,10);end.writeUInt32LE(central.length,12);end.writeUInt32LE(offset,16);
await fs.writeFile(path.join(out,'source.zip'),Buffer.concat([...localParts,central,end]));
console.log(JSON.stringify({directory:out,htmlBytes:Buffer.byteLength(html),sourceFiles:sourceFiles.length,archiveBytes:offset+central.length+end.length}));
