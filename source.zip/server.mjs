import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const port=Number(process.env.PORT||4187);
const clients=new Set();
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.pdf':'application/pdf','.wav':'audio/wav','.txt':'text/plain; charset=utf-8','.md':'text/plain; charset=utf-8','.wasm':'application/wasm'};
const server=http.createServer((req,res)=>{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/__events'){res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});res.write(': ready\n\n');clients.add(res);req.on('close',()=>clients.delete(res));return;}
  let relative;try{relative=decodeURIComponent(url.pathname);}catch{res.writeHead(400).end();return;}
  const filename=path.resolve(root,'.'+(relative==='/'?'/index.html':relative));
  if(!filename.startsWith(root+path.sep)||filename.includes(path.sep+'.git'+path.sep)){res.writeHead(403).end();return;}
  fs.readFile(filename,(err,data)=>{if(err){res.writeHead(404).end('Not found');return;}const ext=path.extname(filename);res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-cache'});if(ext==='.html'){res.end(data.toString().replace('</body>',`<script>new EventSource('/__events').onmessage=()=>location.reload()</script></body>`));}else res.end(data);});
});
let timer;fs.watch(root,{recursive:true},(_,filename)=>{if(!filename||filename.startsWith('.git'))return;clearTimeout(timer);timer=setTimeout(()=>{for(const client of clients)client.write('data: reload\n\n');},180);});
server.listen(port,'127.0.0.1',()=>console.log(`Local: http://127.0.0.1:${port}`));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{for(const client of clients)client.end();server.close(()=>process.exit(0));});
