import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {STLLoader} from 'three/addons/loaders/STLLoader.js';
import {OBJLoader} from 'three/addons/loaders/OBJLoader.js';
import {ThreeMFLoader} from 'three/addons/loaders/3MFLoader.js';
import {unzipSync,strFromU8} from 'three/addons/libs/fflate.module.js';

const MAX_TRIANGLES=1500000,MAX_FILE=30*1024*1024;
const unitScales={mm:1,cm:10,m:1000,in:25.4};
const modelUnits={micron:.001,millimeter:1,centimeter:10,meter:1000,inch:25.4,foot:304.8};
function validateZip(bytes){
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let end=-1;
  for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65558);i--)if(view.getUint32(i,true)===0x06054b50){end=i;break;}
  if(end<0)throw Error('Файл 3MF не содержит корректный ZIP-каталог.');
  const count=view.getUint16(end+10,true);let offset=view.getUint32(end+16,true),total=0;
  if(count>2000||offset>=bytes.length)throw Error('Этот 3MF слишком сложен для просмотра в браузере.');
  for(let i=0;i<count;i++){
    if(offset+46>bytes.length||view.getUint32(offset,true)!==0x02014b50)throw Error('Повреждён ZIP-каталог 3MF.');
    const compressed=view.getUint32(offset+20,true),uncompressed=view.getUint32(offset+24,true);total+=uncompressed;
    if(uncompressed>64*1024*1024||total>128*1024*1024||uncompressed>Math.max(1,compressed)*1500)throw Error('Распакованный 3MF слишком велик. Экспортируйте облегчённую модель.');
    offset+=46+view.getUint16(offset+28,true)+view.getUint16(offset+30,true)+view.getUint16(offset+32,true);
  }
}
function get3mfScale(bytes){
  validateZip(bytes);const files=unzipSync(bytes);let main;
  if(files['_rels/.rels']){const doc=new DOMParser().parseFromString(strFromU8(files['_rels/.rels']),'application/xml');const relation=[...doc.getElementsByTagName('Relationship')].find(r=>(r.getAttribute('Type')||'').endsWith('/3dmodel'));main=relation?.getAttribute('Target')?.replace(/^\//,'');}
  main=main||Object.keys(files).find(name=>name.toLowerCase().endsWith('.model'));
  if(!main||!files[main])throw Error('В 3MF не найден основной файл модели.');
  const doc=new DOMParser().parseFromString(strFromU8(files[main]),'application/xml');
  if(doc.getElementsByTagName('parsererror').length)throw Error('Повреждено описание модели 3MF.');
  const unit=doc.documentElement.getAttribute('unit')||'millimeter';if(!(unit in modelUnits))throw Error('Неизвестная единица 3MF: '+unit);
  return modelUnits[unit];
}

export function createModelViewport(host,{onStats,onStatus,isVisible=()=>true}={}){
  let renderer;
  try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,stencil:true,preserveDrawingBuffer:true});}
  catch{throw Error('Браузер не смог включить WebGL. Попробуйте другой браузер или включите аппаратное ускорение.');}
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.localClippingEnabled=true;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setClearColor(0xf1f5fb,0);host.append(renderer.domElement);
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(37,1,.01,1000000);camera.up.set(0,0,1);
  const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.12;
  let needsRender=true;controls.addEventListener('change',()=>{needsRender=true;});
  controls.screenSpacePanning=true;controls.enablePan=true;
  scene.add(new THREE.HemisphereLight(0xe6f0ff,0x6b7890,2.4));
  const key=new THREE.DirectionalLight(0xffffff,3.1);key.position.set(80,-100,160);scene.add(key);
  const fill=new THREE.DirectionalLight(0xc7dcff,1.4);fill.position.set(-100,80,50);scene.add(fill);
  const model=new THREE.Group();scene.add(model);let content=null,grid=null,stencilGroup=null,cap=null,bounds=new THREE.Box3(),parts=[],unitless=false,baseScale=1,displayUnit='mm',style='solid',name='Демо-фланец',format='Учебная демонстрация',disposed=false,frame=0,activeWorker=null,workerReject=null,loadGeneration=0;
  const clipPlane=new THREE.Plane(new THREE.Vector3(1,0,0),0);let section={enabled:false,axis:'x',position:.5,flip:false};
  const defaultMaterial=()=>new THREE.MeshStandardMaterial({color:0x8faed0,metalness:.28,roughness:.44,side:THREE.DoubleSide});
  function materialList(mesh){return Array.isArray(mesh.material)?mesh.material:[mesh.material];}
  function disposeObject(object){if(!object)return;const geometries=new Set(),materials=new Set();object.traverse(child=>{if(child.geometry)geometries.add(child.geometry);if(child.material)materialList(child).forEach(m=>materials.add(m));});geometries.forEach(g=>g.dispose());materials.forEach(m=>{for(const value of Object.values(m))if(value?.isTexture)value.dispose();m.dispose();});}
  function clearSectionHelpers(){if(stencilGroup){stencilGroup.traverse(c=>{if(c.material)c.material.dispose();});scene.remove(stencilGroup);stencilGroup=null;}if(cap){cap.geometry.dispose();cap.material.dispose();scene.remove(cap);cap=null;}}
  function constructSectionHelpers(){
    clearSectionHelpers();stencilGroup=new THREE.Group();scene.add(stencilGroup);model.updateMatrixWorld(true);
    for(const mesh of parts){
      for(const [side,operation] of [[THREE.BackSide,THREE.IncrementWrapStencilOp],[THREE.FrontSide,THREE.DecrementWrapStencilOp]]){
        const material=new THREE.MeshBasicMaterial({depthWrite:false,depthTest:false,colorWrite:false,stencilWrite:true,stencilFunc:THREE.AlwaysStencilFunc,side,clippingPlanes:[clipPlane],stencilFail:operation,stencilZFail:operation,stencilZPass:operation});
        const stencil=new THREE.Mesh(mesh.geometry,material);stencil.matrixAutoUpdate=false;stencil.matrix.copy(mesh.matrixWorld);stencil.renderOrder=1;stencil.userData.source=mesh;stencilGroup.add(stencil);
      }
    }
    const size=bounds.getSize(new THREE.Vector3()).length()*1.7;
    cap=new THREE.Mesh(new THREE.PlaneGeometry(size,size),new THREE.MeshBasicMaterial({color:0xf0ba75,side:THREE.DoubleSide,depthWrite:true,stencilWrite:true,stencilRef:0,stencilFunc:THREE.NotEqualStencilFunc,stencilFail:THREE.ReplaceStencilOp,stencilZFail:THREE.ReplaceStencilOp,stencilZPass:THREE.ReplaceStencilOp}));
    cap.renderOrder=3;cap.onAfterRender=()=>renderer.clearStencil();scene.add(cap);updateSection();
  }
  function updateSection(){
    needsRender=true;
    const normal=new THREE.Vector3();normal[section.axis]=section.flip?-1:1;
    const position=THREE.MathUtils.lerp(bounds.min[section.axis],bounds.max[section.axis],section.position);
    clipPlane.normal.copy(normal);clipPlane.constant=-position*(section.flip?-1:1);
    for(const mesh of parts)for(const material of materialList(mesh)){material.clippingPlanes=section.enabled?[clipPlane]:null;material.needsUpdate=true;}
    if(stencilGroup){stencilGroup.visible=section.enabled&&style!=='wire';for(const child of stencilGroup.children)child.visible=child.userData.source.visible;}
    if(cap){cap.visible=section.enabled&&style!=='wire';cap.position.copy(bounds.getCenter(new THREE.Vector3()));cap.position[section.axis]=position;cap.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),normal);}
  }
  function applyStyle(){for(const mesh of parts)for(const material of materialList(mesh)){material.wireframe=style==='wire';material.transparent=style==='xray';material.opacity=style==='xray'?.27:1;material.depthWrite=style!=='xray';material.needsUpdate=true;}updateSection();}
  function resize(){const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();needsRender=true;}
  const observer=new ResizeObserver(resize);observer.observe(host);
  function animate(){if(disposed)return;frame=requestAnimationFrame(animate);if(!isVisible()||!host.clientWidth||!host.clientHeight)return;controls.update();if(needsRender){renderer.render(scene,camera);needsRender=false;}}
  function fit(){if(bounds.isEmpty())return;const center=bounds.getCenter(new THREE.Vector3()),radius=bounds.getSize(new THREE.Vector3()).length()/2,vertical=THREE.MathUtils.degToRad(camera.fov/2),horizontal=Math.atan(Math.tan(vertical)*camera.aspect),distance=radius/Math.sin(Math.min(vertical,horizontal))*1.1;let direction=camera.position.clone().sub(controls.target);if(direction.lengthSq()<.001)direction.set(1,-1,.8);direction.normalize();controls.target.copy(center);camera.position.copy(center).addScaledVector(direction,distance);camera.near=Math.max(radius/10000,.001);camera.far=Math.max(radius*1000,100);controls.minDistance=Math.max(radius*.05,.01);controls.maxDistance=radius*40;camera.updateProjectionMatrix();controls.update();}
  function publishStats(){onStats?.({name,format,unitless,unit:displayUnit,size:bounds.getSize(new THREE.Vector3()).toArray(),triangles:parts.reduce((n,m)=>n+(m.geometry.index?m.geometry.index.count:m.geometry.attributes.position.count)/3,0),parts:parts.map((m,i)=>({id:String(i),name:m.name||`Объект ${i+1}`,visible:m.visible}))});}
  function locateModel(){
    content.scale.setScalar(baseScale*(unitless?unitScales[displayUnit]:1));model.position.set(0,0,0);model.updateMatrixWorld(true);const original=new THREE.Box3().setFromObject(content),center=original.getCenter(new THREE.Vector3());
    model.position.set(-center.x,-center.y,-original.min.z);model.updateMatrixWorld(true);bounds.setFromObject(model);
    if(grid){scene.remove(grid);grid.geometry.dispose();materialList(grid).forEach(m=>m.dispose());}
    const extent=Math.max(bounds.getSize(new THREE.Vector3()).length()*1.8,1),division=20;grid=new THREE.GridHelper(extent,division,0xb5c6dc,0xd8e2ef);grid.rotation.x=Math.PI/2;grid.position.z=-Math.max(extent*.0005,.005);grid.material.transparent=true;grid.material.opacity=.65;grid.visible=gridEnabled;scene.add(grid);
    constructSectionHelpers();publishStats();fit();
  }
  let gridEnabled=true;
  function install(candidate,meta){
    let triangles=0,meshes=[];candidate.updateMatrixWorld(true);candidate.traverse(object=>{if(!object.isMesh)return;const p=object.geometry?.attributes.position;if(!p||p.count<3)return;triangles+=(object.geometry.index?object.geometry.index.count:p.count)/3;meshes.push(object);});
    const box=new THREE.Box3().setFromObject(candidate),size=box.getSize(new THREE.Vector3());
    if(!meshes.length||box.isEmpty()||!Number.isFinite(size.length())||size.length()<=0){disposeObject(candidate);throw Error('В файле не найдена подходящая трёхмерная геометрия.');}
    if(triangles>MAX_TRIANGLES){disposeObject(candidate);throw Error('В модели больше 1,5 млн треугольников. Экспортируйте облегчённую копию.');}
    clearSectionHelpers();if(content){model.remove(content);disposeObject(content);}content=candidate;parts=meshes;name=meta.name;format=meta.format;unitless=meta.unitless;displayUnit='mm';baseScale=meta.scale||1;
    parts.forEach((mesh,i)=>{materialList(mesh).forEach(m=>m.dispose());mesh.material=defaultMaterial();mesh.renderOrder=2;if(meta.colors?.[i])mesh.material.color.fromArray(meta.colors[i]);});model.add(content);locateModel();applyStyle();
  }
  function loadDemo(){
    cancelWorker();loadGeneration++;const group=new THREE.Group();
    const base=new THREE.Shape();base.absarc(0,0,34,0,Math.PI*2,false);const center=new THREE.Path();center.absarc(0,0,12,0,Math.PI*2,true);base.holes.push(center);
    for(let i=0;i<6;i++){const a=i*Math.PI/3,hole=new THREE.Path();hole.absarc(Math.cos(a)*26,Math.sin(a)*26,3.2,0,Math.PI*2,true);base.holes.push(hole);}
    const baseMesh=new THREE.Mesh(new THREE.ExtrudeGeometry(base,{depth:8,bevelEnabled:true,bevelSize:.6,bevelThickness:.5,bevelSegments:2,curveSegments:64}),defaultMaterial());baseMesh.name='Фланец';group.add(baseMesh);
    const neck=new THREE.Shape();neck.absarc(0,0,19,0,Math.PI*2,false);const opening=new THREE.Path();opening.absarc(0,0,12,0,Math.PI*2,true);neck.holes.push(opening);const neckMesh=new THREE.Mesh(new THREE.ExtrudeGeometry(neck,{depth:31,bevelEnabled:true,bevelSize:.4,bevelThickness:.4,bevelSegments:2,curveSegments:64}),defaultMaterial());neckMesh.position.z=8;neckMesh.name='Горловина';group.add(neckMesh);
    install(group,{name:'Демо-фланец',format:'Учебная демонстрация · мм',unitless:false});
  }
  function cancelWorker(){if(activeWorker){activeWorker.terminate();activeWorker=null;}if(workerReject){workerReject(Error('Загрузка STEP отменена.'));workerReject=null;}}
  function readCAD(buffer){
    cancelWorker();return new Promise((resolve,reject)=>{let done=false;workerReject=reject;const worker=new Worker(new URL('./assets/vendor/cad-worker.js',import.meta.url));activeWorker=worker;const timer=setTimeout(()=>finish(Error('STEP обрабатывается слишком долго. Попробуйте облегчённую копию.')),90000);
      function finish(error,value){if(done)return;done=true;clearTimeout(timer);worker.terminate();if(activeWorker===worker){activeWorker=null;workerReject=null;}if(error)reject(error);else resolve(value);}
      worker.onmessage=e=>{if(e.data.status){onStatus?.(e.data.status);return;}if(e.data.error)finish(Error(e.data.error));else finish(null,e.data.result);};worker.onerror=()=>finish(Error('Не удалось загрузить модуль чтения STEP. Обновите страницу и попробуйте снова.'));worker.postMessage({buffer},[buffer]);
    });
  }
  async function loadFile(file){
    const generation=++loadGeneration;cancelWorker();const ext=file.name.split('.').pop().toLowerCase();if(!['stl','obj','3mf','step','stp'].includes(ext))throw Error('Поддерживаются STL, OBJ, 3MF и STEP/STP.');if(file.size>MAX_FILE)throw Error('Файл больше 30 МБ. Откройте облегчённую копию.');if(file.size===0)throw Error('Выбран пустой файл.');
    let candidate,scale=1,colors;const buffer=await file.arrayBuffer();if(disposed||generation!==loadGeneration)return;
    try{
      if(ext==='stl'){if(buffer.byteLength>=84){const count=new DataView(buffer).getUint32(80,true);if(count*50+84===buffer.byteLength&&count>MAX_TRIANGLES)throw Error('В STL слишком много треугольников.');}candidate=new THREE.Mesh(new STLLoader().parse(buffer),defaultMaterial());}
      if(ext==='obj')candidate=new OBJLoader().parse(new TextDecoder().decode(buffer));
      if(ext==='3mf'){scale=get3mfScale(new Uint8Array(buffer));const manager=new THREE.LoadingManager();manager.setURLModifier(url=>{if(/^(blob:|data:)/.test(url))return url;throw Error('Внешние ресурсы 3MF не подключаются.');});candidate=new ThreeMFLoader(manager).parse(buffer);}
      if(ext==='step'||ext==='stp'){
        onStatus?.('Загружаю CAD-модуль и читаю STEP локально…');const result=await readCAD(buffer);if(disposed||generation!==loadGeneration)return;
        if(!result.success||!result.meshes?.length)throw Error('STEP не удалось прочитать. Проверьте файл или экспортируйте его заново.');candidate=new THREE.Group();colors=[];
        for(const mesh of result.meshes){const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(mesh.attributes.position.array,3));if(mesh.attributes.normal)geometry.setAttribute('normal',new THREE.Float32BufferAttribute(mesh.attributes.normal.array,3));geometry.setIndex(mesh.index.array);if(!mesh.attributes.normal)geometry.computeVertexNormals();const object=new THREE.Mesh(geometry,defaultMaterial());object.name=mesh.name||'Деталь STEP';candidate.add(object);colors.push(mesh.color||[.56,.68,.82]);}
      }
    }catch(error){if(candidate)disposeObject(candidate);throw Error(/[А-Яа-яЁё]/.test(error.message||'')?error.message:'Не удалось прочитать геометрию. Файл повреждён или использует неподдерживаемую структуру.');}
    if(disposed||generation!==loadGeneration){disposeObject(candidate);return;}
    install(candidate,{name:file.name,format:ext==='step'||ext==='stp'?'STEP · миллиметры':ext==='3mf'?'3MF · единицы из файла':ext.toUpperCase()+' · проверьте единицы',unitless:['stl','obj'].includes(ext),scale,colors});
  }
  resize();camera.position.set(100,-135,110);animate();
  return {loadFile,loadDemo,fit,setSection(value){section={...section,...value};updateSection();},setStyle(value){style=value;applyStyle();},setGrid(value){gridEnabled=value;if(grid)grid.visible=value;needsRender=true;},setUnits(value){if(unitless&&unitScales[value]){displayUnit=value;locateModel();}},setPartVisible(id,visible){const mesh=parts[Number(id)];if(mesh){mesh.visible=visible;updateSection();}},setCamera(view){const directions={iso:[1,-1,.8],front:[0,-1,0],top:[0,0,1],back:[0,1,0],left:[-1,0,0],right:[1,0,0]};const d=directions[view]||directions.iso;camera.position.copy(controls.target).add(new THREE.Vector3(...d));if(view==='top')camera.position.y-=.001;fit();},snapshot(){renderer.render(scene,camera);renderer.domElement.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='3d-view.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);},'image/png');},dispose(){disposed=true;loadGeneration++;cancelWorker();cancelAnimationFrame(frame);observer.disconnect();controls.dispose();clearSectionHelpers();if(content)disposeObject(content);if(grid){grid.geometry.dispose();materialList(grid).forEach(m=>m.dispose());}renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();}};
}
