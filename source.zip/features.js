'use strict';

// Additional desktop applications share the existing window manager.
window.installPortfolioFeatures = api => {
  const {$, $$, escape:esc, asset, icon, icons, store, state, appInfo, folders,
    desktopEntries, startEntries, openApp, openFolder, runEntry, focusWindow,
    closeWindow, updateTitle, toast, downloadText, aboutText, cadText,
    renderDesktop, renderStart, closeMenus, registerApp} = api;
  const releaseFile = name => `./dist/${name}`;
  Object.assign(icons,{browser:icon('browser.svg'),paint:icon('paint.svg'),user:icon('user.svg'),tasks:icon('tasks.svg')});
  const entryKey = e => e.folder ? `folder-${e.folder}` : `app-${e.app}-${e.variant||''}`;
  const projectInfo = {
    bug:{title:'Конструктор баг-репортов',purpose:'Превращает описание ошибки в структурированный Markdown-отчёт: шаги, ожидание, фактический результат и окружение.',tools:'HTML · CSS · JavaScript · localStorage · Markdown',role:'Выбрал задачу для учебного проекта, сформулировал требования к форме и результату. Реализация и проверки выполнены с помощью Codex. Моя роль — постановка задачи и оценка результата.',checks:['Нажмите «Пример»: поля и готовый отчёт должны заполниться.','Измените шаги — нумерация в отчёте обновится.','Скачайте .md и сравните текст с предпросмотром.','Закройте приложение и откройте снова: черновик сохранится в этом браузере.']},
    cost:{title:'Калькулятор затрат на 3D-печать',purpose:'Считает прямые затраты по массе детали, цене материала, времени печати, стоимости часа и подготовке. Прибыль, налоги и брак в расчёт не входят.',tools:'HTML · CSS · JavaScript · проверка числовых полей · Intl.NumberFormat',role:'Выбрал тему, связанную с обучением аддитивным технологиям, и задал нужные исходные данные. Код и проверка расчётов подготовлены с помощью Codex.',checks:['При значениях 40 г, 1 200 ₽/кг, 3 ч, 50 ₽/ч и 100 ₽ результат — 298 ₽.','Измените массу на 80 г: итог должен стать 346 ₽.','Отрицательное или пустое обязательное значение должно убрать результат.','Верните корректные значения: расчёт должен восстановиться.']},
    site:{title:'Портфолио в стиле Windows 7',purpose:'Интерактивный сайт: рабочий стол, документы, проекты и небольшие приложения в знакомом интерфейсе Windows 7 Aero.',tools:'HTML · CSS · JavaScript · 7.css (MIT) · Node.js для сборки · GitHub Pages',role:'Предложил концепцию Windows 7, выбрал визуальное направление и функции, уточнял результат. Реализация, отладка и публикация выполнены с помощью Codex.',checks:['Перетащите ярлык, обновите страницу и снова войдите: его положение сохранится.','Откройте папку, воспользуйтесь поиском, затем меню «Свойства».','Сверните окно и восстановите его через панель задач.','Попробуйте сайт на телефоне: достаточно одного нажатия по ярлыку.']},
    paint:{title:'Paint',purpose:'Небольшая рисовалка: кисть, карандаш, ластик, линии и фигуры. Рисунок можно сохранить в PNG.',tools:'HTML · CSS · JavaScript · Canvas 2D · Pointer Events',role:'Дополнение к портфолио по моему запросу сделать рабочий стол интерактивнее. Реализовано с помощью Codex.',checks:['Нарисуйте линию и нажмите «Отменить».','Попробуйте фигуру и ластик.','Сохраните PNG: изображение должно содержать рисунок.']},
    browser:{title:'Internet Explorer',purpose:'Браузер внутри портфолио: вкладки, адресная строка, история и избранное. Внешние страницы работают в рамках ограничений обычного сайта.',tools:'HTML · CSS · JavaScript · iframe',role:'Выбрал браузер как часть рабочего стола в стиле Windows 7. Интерфейс и логика реализованы с помощью Codex.',checks:['Откройте новую вкладку и вернитесь назад по истории.','Добавьте страницу в избранное и откройте её из списка.','Для внешней страницы используйте «Открыть отдельно», если встроенный просмотр недоступен.']}
  };

  function saveLink(url,name){const a=document.createElement('a');a.href=url;a.download=name;a.rel='noopener';a.click();}
  function downloadable(entry){return !!entry && entry.app!=='recycle' && entry.app!=='computer';}
  async function downloadEntry(entry){
    if(!downloadable(entry))return;
    if(entry.folder){saveLink(releaseFile('source.zip'),'Yaroslav_Portfolio_source.zip');return;}
    if(entry.app==='resume'){const variant=entry.variant==='cad'?'CAD':'AI';saveLink(asset(`documents/Yaroslav_Beloglazov_${variant}.pdf`),`Yaroslav_Beloglazov_${variant}.pdf`);return;}
    if(entry.app==='about'||entry.app==='cad'){downloadText(entry.app==='cad'?'Навыки CAD.txt':'Обо мне.txt',entry.app==='cad'?cadText:aboutText);return;}
    if(entry.app==='contacts'){downloadText('Контакты.txt','Белоглазов Ярослав Михайлович\nTelegram: https://t.me/kyzenYB\nПочта: yarick3435@mail.ru\nТелефон: +7 (925) 620-21-99\nСайт: https://zef1r34.github.io/\n');return;}
    if(['bug','cost','paint','browser'].includes(entry.app)){
      toast('Подготовка приложения','Собираю HTML-файл, который можно открыть отдельно.');
      try{
        const response=await fetch(releaseFile('index.html'),{cache:'no-cache'});
        if(!response.ok)throw Error('HTTP '+response.status);
        let html=await response.text();
        if(!html.includes('portfolioAssetData'))throw Error('Сборка не найдена');
        html=html.replace(/<body(?:\s[^>]*)?>/,`<body data-start-app="${entry.app}">`);
        downloadText(`Yaroslav_${entry.app}.html`,html,'text/html;charset=utf-8');
        toast('Приложение готово','HTML-файл можно открыть в браузере. Внешним страницам потребуется интернет.');
      }catch{toast('Не удалось скачать приложение','Попробуйте ещё раз с опубликованного сайта.');}
      return;
    }
    if(['site','viewer'].includes(entry.app)){saveLink(releaseFile('source.zip'),'Yaroslav_Portfolio_source.zip');return;}
    downloadText(`${entry.name||appInfo[entry.app]?.title||'Проект'}.txt`,`${projectInfo[entry.app]?.title||entry.name}\n\n${projectInfo[entry.app]?.purpose||aboutText}\n\nСайт: https://zef1r34.github.io/\nTelegram: @kyzenYB`);
  }

  registerApp('recruiter',{title:'Сведения о пользователе',icon:icons.user,width:805,height:605},win=>{
    win.content.innerHTML=`<div class="system-path"><img src="${icons.user}" alt="">Панель управления <span>›</span> Сведения о пользователе</div>
      <div class="recruiter-page"><div class="recruiter-heading"><div><h2>Ярослав Белоглазов</h2><p>ИИ-инструменты, цифровые продукты и 3D-моделирование</p></div><img src="${asset('icons/avatar.svg')}" alt="" class="profile-picture"></div>
      <h3>Какую работу ищу</h3><p>Начинающий специалист по работе с ИИ-инструментами или CAD-моделированию. Интересны создание и проверка сайтов, приложений и автоматизаций с помощью ИИ.</p>
      <dl class="system-facts"><dt>Формат</dt><dd>Полный день · удалённо по России, офис / гибрид в Москве и Долгопрудном</dd><dt>Навыки ИИ</dt><dd>Постановка задач для ChatGPT и Codex, проверка результата, поиск и описание ошибок. Личные эксперименты с MCP и Roblox.</dd><dt>Навыки CAD</dt><dd>Самостоятельно делаю детали по чертежам и сборки в КОМПАС-3D, Creo Parametric и SolidWorks.</dd><dt>Образование</dt><dd>Политехнический колледж № 8 им. И. Ф. Павлова, «Аддитивные технологии». Выпуск — лето 2027 года.</dd></dl>
      <h3>Попробуйте учебные проекты</h3><div class="recruiter-projects"><button data-open="bug"><img src="${icons.bug}" alt=""><span><strong>Баг-репорт</strong><small>Форма → готовый Markdown</small></span></button><button data-open="cost"><img src="${icons.cube}" alt=""><span><strong>Калькулятор 3D-печати</strong><small>Масса, материал и время → затраты</small></span></button></div>
      <p class="profile-note">Проекты созданы с помощью ИИ под моим руководством. Коммерческого опыта в IT пока нет.</p><div class="profile-actions"><button data-open="resume">Открыть резюме PDF</button><a href="https://t.me/kyzenYB" target="_blank" rel="noopener">Написать в Telegram ↗</a><a href="mailto:yarick3435@mail.ru">yarick3435@mail.ru</a></div></div>`;
  });

  registerApp('properties',{title:'Свойства',icon:icons.settings,width:555,height:530},(win,options)=>{
    let currentEntry;
    const draw=entry=>{
      currentEntry=entry||{name:'Портфолио',app:'site',icon:icons.windows};
      const e=currentEntry,project=projectInfo[e.app],title=e.name||appInfo[e.app]?.title||'Портфолио';
      updateTitle(win,`${title}: свойства`);
      const tabs=project?['Описание','Инструменты','Мой вклад','Проверка']:['Общие'];
      const general=`<dl class="property-facts"><dt>Тип</dt><dd>${esc(e.type||(e.folder?'Папка с файлами':'Ярлык приложения'))}</dd><dt>Размещение</dt><dd>Портфолио Ярослава Белоглазова</dd><dt>Открывается</dt><dd>В окне этого сайта</dd></dl><p>${esc(e.folder?folders[e.folder]?.description||'':e.app==='resume'?'Одностраничное резюме. Скачать можно оригинальный PDF.':e.app==='cad'?'Навыки самостоятельного CAD-моделирования. Образцы моделей пока не опубликованы.':e.app==='about'?'Краткая информация об образовании, навыках и интересах.':e.app==='contacts'?'Telegram, электронная почта и телефон для связи.':'Элемент интерактивного рабочего стола.')}</p>`;
      const pages=project?[`<h3>Для чего этот проект</h3><p>${esc(project.purpose)}</p><p class="property-note">Статус: работающий учебный проект.</p>`,`<h3>Инструменты</h3><p>${esc(project.tools)}</p><p>Работает в браузере. Для запуска мини-приложений не нужен платный ИИ API.</p>`,`<h3>Мой вклад</h3><p>${esc(project.role)}</p>`,`<h3>Что можно проверить</h3><ol>${project.checks.map(s=>`<li>${esc(s)}</li>`).join('')}</ol>`]:[general];
      win.content.innerHTML=`<div class="properties-page"><div role="tablist" aria-label="Разделы свойств">${tabs.map((name,i)=>`<button role="tab" id="property-tab-${i}" aria-selected="${i===0}" aria-controls="property-panel-${i}" tabindex="${i===0?0:-1}" data-property-tab="${i}">${name}</button>`).join('')}</div><div class="property-box"><div class="property-heading"><img src="${e.icon||icons.folder}" alt=""><strong>${esc(title)}</strong></div>${pages.map((p,i)=>`<div role="tabpanel" id="property-panel-${i}" aria-labelledby="property-tab-${i}" ${i?'hidden':''}>${p}</div>`).join('')}</div><div class="property-buttons"><button data-property-open>Открыть</button><button data-property-download ${downloadable(e)?'':'disabled'}>${e.folder||e.app==='site'?'Скачать исходники':'Скачать'}</button><button data-property-close>ОК</button></div></div>`;
    };
    win.updateOptions=options=>{if(options.entry)draw(options.entry);};
    const select=index=>{$$('[role="tab"]',win.content).forEach((tab,i)=>{tab.setAttribute('aria-selected',i===index);tab.tabIndex=i===index?0:-1;});$$('[role="tabpanel"]',win.content).forEach((panel,i)=>panel.hidden=i!==index);};
    win.content.addEventListener('click',e=>{const tab=e.target.closest('[data-property-tab]');if(tab)select(Number(tab.dataset.propertyTab));if(e.target.closest('[data-property-open]'))runEntry(currentEntry);if(e.target.closest('[data-property-download]'))downloadEntry(currentEntry);if(e.target.closest('[data-property-close]'))closeWindow(win.id);});
    win.content.addEventListener('keydown',e=>{const tab=e.target.closest('[role="tab"]');if(!tab)return;const all=$$('[role="tab"]',win.content),i=all.indexOf(tab);let next;if(e.key==='ArrowRight')next=(i+1)%all.length;if(e.key==='ArrowLeft')next=(i+all.length-1)%all.length;if(e.key==='Home')next=0;if(e.key==='End')next=all.length-1;if(next!==undefined){e.preventDefault();select(next);all[next].focus();}});
    draw(options.entry);
  });

  // One menu is shared by Explorer items and desktop shortcuts.
  const fileMenu=document.createElement('div');fileMenu.className='context-menu file-context-menu';fileMenu.hidden=true;fileMenu.setAttribute('role','menu');fileMenu.setAttribute('aria-label','Действия с файлом');document.body.append(fileMenu);
  let contextEntry=null,contextTarget=null;
  const oldClose=state.onCloseMenus;
  state.onCloseMenus=()=>{oldClose?.();fileMenu.hidden=true;};
  const resolveEntry=target=>{
    const desktop=target.closest('[data-desktop]');if(desktop)return {entry:desktopEntries[Number(desktop.dataset.desktop)],element:desktop};
    const file=target.closest('[data-file]'),explorer=state.windows.get('explorer');if(file&&explorer&&explorer.element.contains(file))return {entry:folders[explorer.folder].items[Number(file.dataset.file)],element:file};
    return null;
  };
  function showFileMenu(target,x,y){
    const resolved=resolveEntry(target);if(!resolved?.entry)return;
    closeMenus();contextEntry=resolved.entry;contextTarget=resolved.element;
    const all=contextTarget.matches('[data-desktop]')?$$('[data-desktop]'):$$('[data-file]',state.windows.get('explorer').content);
    all.forEach(el=>el.classList.toggle('selected',el===contextTarget));
    if(contextTarget.matches('[data-file]')){const win=state.windows.get('explorer');win.selected=Number(contextTarget.dataset.file);$('[data-file-selection]',win.content).textContent=contextEntry.name;}
    fileMenu.innerHTML=`<button role="menuitem" data-file-command="open"><strong>Открыть</strong></button><button role="menuitem" data-file-command="download" ${downloadable(contextEntry)?'':'disabled'}>${contextEntry.folder||contextEntry.app==='site'?'Скачать исходники':'Скачать'}</button><hr role="separator"><button role="menuitem" data-file-command="properties">Свойства</button>`;
    fileMenu.hidden=false;fileMenu.style.left=`${Math.max(4,Math.min(x,innerWidth-fileMenu.offsetWidth-5))}px`;fileMenu.style.top=`${Math.max(4,Math.min(y,innerHeight-fileMenu.offsetHeight-48))}px`;
    $('[role="menuitem"]',fileMenu).focus({preventScroll:true});
  }
  document.addEventListener('contextmenu',e=>{if(resolveEntry(e.target)){e.preventDefault();e.stopPropagation();showFileMenu(e.target,e.clientX,e.clientY);}},true);
  document.addEventListener('pointerdown',e=>{if(!e.target.closest('.file-context-menu'))fileMenu.hidden=true;});
  fileMenu.addEventListener('click',e=>{const command=e.target.closest('[data-file-command]')?.dataset.fileCommand,entry=contextEntry;if(!command||!entry)return;fileMenu.hidden=true;if(command==='open')runEntry(entry);if(command==='download')downloadEntry(entry);if(command==='properties')openApp('properties',{entry});});
  fileMenu.addEventListener('keydown',e=>{const buttons=$$('button:not(:disabled)',fileMenu),index=buttons.indexOf(document.activeElement);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();buttons[(index+buttons.length+(e.key==='ArrowDown'?1:-1))%buttons.length].focus();}if(e.key==='Escape'){fileMenu.hidden=true;contextTarget?.focus();}});
  document.addEventListener('keydown',e=>{
    const entry=resolveEntry(e.target);if(!entry)return;
    if(e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10')){e.preventDefault();const rect=entry.element.getBoundingClientRect();showFileMenu(e.target,rect.left+rect.width/2,rect.top+rect.height/2);}
    if(e.altKey&&e.key==='Enter'){e.preventDefault();openApp('properties',{entry:entry.entry});}
    if(e.key==='Enter'&&e.target.matches('[data-file],[data-desktop]')){e.preventDefault();runEntry(entry.entry);}
  });

  // Shortcuts use absolute coordinates; layouts for phones and desktops are separate.
  const desktop=$('#desktop-icons');
  const layoutKey=()=>innerWidth<=640?'portfolio-icons-mobile-v2':'portfolio-icons-desktop-v2';
  const dimensions=()=>({w:desktop.clientWidth||innerWidth,h:desktop.clientHeight||innerHeight-47,iw:innerWidth<=640?87:92,ih:innerWidth<=640?88:96});
  function positionShortcuts(reset=false){
    const {w,h,iw,ih}=dimensions(),rows=Math.max(1,Math.floor((h-12)/(ih+8))),saved=reset?{}:store.get(layoutKey(),{});
    $$('[data-desktop]',desktop).forEach((button,i)=>{const key=entryKey(desktopEntries[i]),p=saved[key]||{x:8+Math.floor(i/rows)*(iw+10),y:8+(i%rows)*(ih+8)};button.style.left=`${Math.max(0,Math.min(w-iw,p.x))}px`;button.style.top=`${Math.max(0,Math.min(h-ih,p.y))}px`;});
  }
  state.onDesktopRender=()=>positionShortcuts();
  let suppressUntil=0;
  desktop.addEventListener('dragstart',e=>e.preventDefault());
  desktop.addEventListener('pointerdown',e=>{
    const target=e.target.closest('[data-desktop]');if(!target||e.button!==0)return;
    const start={x:e.clientX,y:e.clientY,left:target.offsetLeft,top:target.offsetTop};let moved=false;
    target.setPointerCapture(e.pointerId);
    const move=event=>{if(Math.hypot(event.clientX-start.x,event.clientY-start.y)<6&&!moved)return;moved=true;target.classList.add('dragging','selected');const {w,h,iw,ih}=dimensions();target.style.left=`${Math.max(0,Math.min(w-iw,start.left+event.clientX-start.x))}px`;target.style.top=`${Math.max(0,Math.min(h-ih,start.top+event.clientY-start.y))}px`;};
    const end=event=>{target.removeEventListener('pointermove',move);target.removeEventListener('pointerup',end);target.removeEventListener('pointercancel',end);target.classList.remove('dragging');if(target.hasPointerCapture(event.pointerId))target.releasePointerCapture(event.pointerId);if(moved){suppressUntil=performance.now()+450;const positions={};$$('[data-desktop]',desktop).forEach((button,i)=>positions[entryKey(desktopEntries[i])]={x:button.offsetLeft,y:button.offsetTop});store.set(layoutKey(),positions);}};
    target.addEventListener('pointermove',move);target.addEventListener('pointerup',end);target.addEventListener('pointercancel',end);
  });
  for(const type of ['click','dblclick'])desktop.addEventListener(type,e=>{if(performance.now()<suppressUntil){e.preventDefault();e.stopImmediatePropagation();}},true);
  desktop.addEventListener('click',e=>{if(e.target===desktop)$$('[data-desktop]',desktop).forEach(el=>el.classList.remove('selected'));});
  window.addEventListener('resize',()=>{positionShortcuts();fileMenu.hidden=true;});
  const arrange=document.createElement('button');arrange.textContent='Упорядочить значки';arrange.addEventListener('click',()=>{store.set(layoutKey(),{});positionShortcuts(true);closeMenus();});$('#desktop-menu').insertBefore(arrange,$('#refresh-desktop'));

  // Browser tabs and histories describe navigation initiated through this shell.
  registerApp('browser',{title:'Internet Explorer',icon:icons.browser,width:980,height:640},(win,options)=>{
    let tabs=[],active=0,nextId=1,showFavorites=false;
    let favorites=store.get('portfolio-browser-favorites',[{name:'Моё портфолио',url:'about:portfolio'},{name:'Первый сайт в мире',url:'https://info.cern.ch/hypertext/WWW/TheProject.html'},{name:'GitHub',url:'https://github.com/zef1r34/zef1r34.github.io'}]);
    if(!Array.isArray(favorites))favorites=[];
    const normalise=value=>{const input=value.trim();if(['about:home','about:portfolio','about:help'].includes(input))return input;if(!input)return 'about:home';if(input.startsWith('about:'))throw Error('Такой внутренней страницы нет.');if(/^[a-z][a-z\d+.-]*:/i.test(input)&&!/^https?:/i.test(input))throw Error('Введите адрес сайта с https://.');const looksLikeURL=/^https?:\/\//i.test(input)||/^[\w\u0400-\u04ff.-]+\.[a-z\u0400-\u04ff]{2,}(?::\d+)?(?:[/?#]|$)/i.test(input);if(!looksLikeURL)return `https://www.google.com/search?q=${encodeURIComponent(input)}`;const url=new URL(/^https?:\/\//i.test(input)?input:'https://'+input);url.protocol='https:';if(url.username||url.password)throw Error('Адрес с логином или паролем не поддерживается.');return url.href;};
    const label=url=>url==='about:home'?'Новая вкладка':url==='about:portfolio'?'Портфолио':url==='about:help'?'Справка':new URL(url).hostname;
    const current=()=>tabs.find(t=>t.id===active);
    function addTab(url='about:home'){if(tabs.length>=8){toast('Открыто 8 вкладок','Закройте одну из вкладок, чтобы добавить новую.');return;}const tab={id:nextId++,history:[url],index:0,embed:false};tabs.push(tab);active=tab.id;render();}
    function navigate(value){try{const url=normalise(value),tab=current();tab.history=tab.history.slice(0,tab.index+1);tab.history.push(url);tab.index++;tab.embed=false;render();}catch(error){$('.ie-feedback',win.content).textContent=error.message;}}
    function render(){
      const tab=current(),url=tab.history[tab.index],external=!url.startsWith('about:'),canEmbed=external&&new URL(url).hostname==='info.cern.ch';
      updateTitle(win,`${label(url)} — Internet Explorer`);
      win.content.innerHTML=`<div class="ie-navigation"><button class="ie-back" data-ie="back" aria-label="Назад в браузере" ${tab.index===0?'disabled':''}>←</button><button class="ie-forward" data-ie="forward" aria-label="Вперёд в браузере" ${tab.index===tab.history.length-1?'disabled':''}>→</button><form class="ie-address-form"><span aria-hidden="true">${external?'🌐':'▣'}</span><input class="ie-address" aria-label="Адрес или поисковый запрос" value="${esc(url)}" spellcheck="false" autocomplete="off"><button type="submit" aria-label="Перейти">➜</button></form><button data-ie="reload" aria-label="Обновить страницу">↻</button><button data-ie="home" aria-label="Домашняя страница">⌂</button><button data-ie="favorite" aria-label="Добавить в избранное">☆</button></div>
        <div class="ie-tabbar" role="tablist" aria-label="Вкладки браузера">${tabs.map(t=>`<div class="ie-tab ${t.id===active?'current':''}"><button role="tab" aria-selected="${t.id===active}" data-ie-tab="${t.id}"><img src="${icons.browser}" alt=""><span>${esc(label(t.history[t.index]))}</span></button><button data-ie-close="${t.id}" aria-label="Закрыть вкладку ${esc(label(t.history[t.index]))}">×</button></div>`).join('')}<button data-ie="new" class="ie-new-tab" aria-label="Новая вкладка">＋</button></div>
        <div class="ie-favorites-bar"><button data-ie="favorites">⭐ Избранное</button>${favorites.slice(0,3).map((f,i)=>`<button data-ie-bookmark="${i}">${esc(f.name)}</button>`).join('')}<span></span>${external?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">Открыть отдельно ↗</a>`:''}</div>
        <div class="ie-feedback" role="status"></div><div class="ie-body">${showFavorites?`<aside class="ie-favorites"><h3>Избранное</h3>${favorites.length?favorites.map((f,i)=>`<div><button data-ie-bookmark="${i}">${esc(f.name)}</button><button data-ie-remove="${i}" aria-label="Удалить ${esc(f.name)} из избранного">×</button></div>`).join(''):'<p>Пока пусто. Нажмите ☆, чтобы добавить страницу.</p>'}</aside>`:''}<div class="ie-page">${page(url,canEmbed||tab.embed)}</div></div><div class="window-status"><span>${external?'Интернет':'Внутренняя страница портфолио'}</span><span>Масштаб 100%</span></div>`;
    }
    function page(url,embed){
      if(url==='about:portfolio')return `<div class="ie-local"><h1>Ярослав Белоглазов</h1><p>ИИ-инструменты · CAD · цифровые эксперименты</p><div class="ie-home-links"><button data-open="recruiter"><img src="${icons.user}" alt="">Для работодателя</button><button data-folder="projects"><img src="${icons.folder}" alt="">Мои проекты</button><button data-open="resume"><img src="${icons.pdf}" alt="">Резюме PDF</button><button data-open="contacts"><img src="${icons.mail}" alt="">Связаться</button></div></div>`;
      if(url==='about:help')return `<div class="ie-local"><h1>Справка Internet Explorer</h1><p>Введите адрес или запрос и нажмите Enter. Кнопки ← и → перемещают по истории выбранной вкладки. Кнопка ☆ сохраняет страницу в избранном этого браузера.</p><p>Это приложение внутри сайта. Некоторые сайты запрещают показ во встроенном окне. Кнопка «Открыть отдельно» открывает их обычной вкладкой. История и адресная строка учитывают переходы из этой оболочки; переходы внутри внешней страницы могут не отражаться в них.</p><button data-ie-url="about:home">Вернуться на домашнюю страницу</button></div>`;
      if(url==='about:home')return `<div class="ie-home"><img class="ie-logo" src="${icons.browser}" alt=""><h1>Добро пожаловать в Интернет</h1><p>Знакомое окно. Можно немного отвлечься.</p><form class="ie-home-search"><input aria-label="Поиск в интернете" placeholder="Введите поисковый запрос"><button type="submit">Найти</button></form><h2>Часто посещаемые сайты</h2><div class="ie-sites"><button data-ie-url="about:portfolio"><span class="site-thumbnail portfolio-thumb"><img src="${icons.user}" alt=""></span><strong>Моё портфолио</strong><small>Кто я и что умею</small></button><button data-ie-url="https://info.cern.ch/hypertext/WWW/TheProject.html"><span class="site-thumbnail cern-thumb">World Wide Web<hr>1991</span><strong>Первый сайт в мире</strong><small>Немного истории интернета</small></button><button data-ie-url="https://github.com/zef1r34/zef1r34.github.io"><span class="site-thumbnail github-thumb">&lt;/&gt;</span><strong>Исходники сайта</strong><small>Открыть на GitHub</small></button></div><a href="#" data-ie-url="about:help" class="ie-help-link">Как работает этот браузер?</a></div>`;
      const host=new URL(url).hostname;
      if(embed)return `<div class="ie-embed-note">Внешняя страница: ${esc(host)} <a href="${esc(url)}" target="_blank" rel="noopener noreferrer">Открыть отдельно ↗</a></div><iframe src="${esc(url)}" title="Внешняя страница ${esc(host)}" sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox" referrerpolicy="no-referrer"></iframe>`;
      return `<div class="ie-external"><img src="${icons.browser}" alt=""><h1>${esc(host)}</h1><p>Внешний сайт удобнее открыть обычной вкладкой. Если сайт разрешает встроенный просмотр, его можно попробовать здесь.</p><p class="ie-url-text">${esc(url)}</p><div><a class="ie-open-link" href="${esc(url)}" target="_blank" rel="noopener noreferrer">Открыть отдельно ↗</a><button data-ie="embed">Попробовать здесь</button></div><small>Правила внешнего сайта могут запрещать отображение в этом окне.</small></div>`;
    }
    win.content.addEventListener('submit',e=>{e.preventDefault();if(e.target.matches('.ie-address-form'))navigate($('input',e.target).value);if(e.target.matches('.ie-home-search'))navigate($('input',e.target).value);});
    win.content.addEventListener('click',e=>{
      const url=e.target.closest('[data-ie-url]');if(url){e.preventDefault();navigate(url.dataset.ieUrl);return;}
      const select=e.target.closest('[data-ie-tab]');if(select){active=Number(select.dataset.ieTab);render();return;}
      const close=e.target.closest('[data-ie-close]');if(close){const id=Number(close.dataset.ieClose),index=tabs.findIndex(t=>t.id===id);tabs=tabs.filter(t=>t.id!==id);if(!tabs.length){addTab();return;}if(active===id)active=tabs[Math.max(0,index-1)].id;render();return;}
      const bookmark=e.target.closest('[data-ie-bookmark]');if(bookmark){navigate(favorites[Number(bookmark.dataset.ieBookmark)].url);return;}
      const remove=e.target.closest('[data-ie-remove]');if(remove){favorites.splice(Number(remove.dataset.ieRemove),1);store.set('portfolio-browser-favorites',favorites);render();return;}
      const action=e.target.closest('[data-ie]')?.dataset.ie,tab=current();if(!action)return;
      if(action==='new'){addTab();$('.ie-address',win.content).focus();$('.ie-address',win.content).select();return;}
      if(action==='back'&&tab.index>0)tab.index--;if(action==='forward'&&tab.index<tab.history.length-1)tab.index++;
      if(action==='home'){navigate('about:home');return;}
      if(action==='favorite'){const url=tab.history[tab.index];if(!favorites.some(f=>f.url===url)){favorites.push({name:label(url),url});store.set('portfolio-browser-favorites',favorites);}else toast('Избранное','Эта страница уже есть в избранном.');}
      if(action==='favorites')showFavorites=!showFavorites;
      if(action==='embed')tab.embed=true;
      render();
    });
    win.content.addEventListener('keydown',e=>{if(e.ctrlKey&&e.key.toLowerCase()==='l'){e.preventDefault();$('.ie-address',win.content).focus();$('.ie-address',win.content).select();}});
    win.updateOptions=options=>{if(options.url)navigate(options.url);};
    addTab(options.url?normalise(options.url):'about:home');
  });

  registerApp('paint',{title:'Безымянный — Paint',icon:icons.paint,width:970,height:640},win=>{
    const colors=['#000000','#7f7f7f','#880015','#ed1c24','#ff7f27','#fff200','#22b14c','#00a2e8','#3f48cc','#a349a4','#ffffff','#c3c3c3','#b97a57','#ffaec9','#ffc90e','#efe4b0','#b5e61d','#99d9ea','#7092be','#c8bfe7'];
    win.content.innerHTML=`<div class="paint-tabs"><button data-paint="save" class="paint-file">Файл ▾</button><button data-paint-view="home" aria-pressed="true">Главная</button><button data-paint-view="view" aria-pressed="false">Вид</button><div class="paint-quick"><button data-paint="undo" aria-label="Отменить рисунок">↶</button><button data-paint="redo" aria-label="Повторить рисунок">↷</button></div></div><div class="paint-ribbon"><div class="paint-home-tools"><div class="paint-group"><div class="paint-tool-buttons">${[['brush','🖌','Кисть'],['pencil','✎','Карандаш'],['eraser','▱','Ластик'],['line','╱','Линия'],['rect','▭','Прямоугольник'],['ellipse','◯','Эллипс']].map(([id,symbol,name])=>`<button data-paint-tool="${id}" aria-label="${name}" title="${name}" aria-pressed="${id==='brush'}">${symbol}</button>`).join('')}</div><span>Инструменты и фигуры</span></div><div class="paint-group"><label>Толщина<select aria-label="Толщина кисти"><option value="2">2 px</option><option value="5" selected>5 px</option><option value="10">10 px</option><option value="20">20 px</option></select></label><span>Размер</span></div><div class="paint-group paint-color-group"><div class="paint-colors">${colors.map(c=>`<button data-color="${c}" style="--swatch:${c}" aria-label="Цвет ${c}" aria-pressed="${c==='#000000'}"></button>`).join('')}</div><span>Цвета</span></div><div class="paint-group"><label class="paint-custom-color"><input type="color" value="#000000" aria-label="Выбрать свой цвет">Изменение<br>цветов</label></div></div><div class="paint-view-tools" hidden><button data-paint="zoom-out">Уменьшить</button><button data-paint="zoom-in">Увеличить</button><button data-paint="zoom-fit">По размеру окна</button><button data-paint="clear">Очистить холст</button></div></div><div class="paint-workspace"><canvas width="960" height="540" aria-label="Холст для рисования"></canvas></div><div class="paint-footer"><span data-paint-status>Кисть · 960 × 540 px</span><button data-paint="save">Сохранить PNG</button><button data-paint="clear">Очистить</button></div>`;
    const canvas=$('canvas',win.content),ctx=canvas.getContext('2d',{willReadFrequently:true});let tool='brush',color='#000000',size=5,drawing=false,start=null,before=null,undo=[],redo=[],zoom=0;
    ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);
    function controls(){$('[data-paint="undo"]',win.content).disabled=!undo.length;$('[data-paint="redo"]',win.content).disabled=!redo.length;const labels={brush:'Кисть',pencil:'Карандаш',eraser:'Ластик',line:'Линия',rect:'Прямоугольник',ellipse:'Эллипс'};$('[data-paint-status]',win.content).textContent=`${labels[tool]} · 960 × 540 px`;}
    const snapshot=()=>ctx.getImageData(0,0,canvas.width,canvas.height);
    function remember(image){undo.push(image);if(undo.length>8)undo.shift();redo=[];controls();updateTitle(win,'Безымянный * — Paint');}
    const point=e=>{const r=canvas.getBoundingClientRect();return {x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height};};
    function style(){ctx.strokeStyle=tool==='eraser'?'#ffffff':color;ctx.fillStyle=ctx.strokeStyle;ctx.lineWidth=tool==='eraser'?Math.max(12,size*3):tool==='pencil'?1:size;ctx.lineCap='round';ctx.lineJoin='round';}
    canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();canvas.setPointerCapture(e.pointerId);drawing=true;before=snapshot();start=point(e);style();ctx.beginPath();ctx.moveTo(start.x,start.y);if(['brush','pencil','eraser'].includes(tool)){ctx.arc(start.x,start.y,ctx.lineWidth/2,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.moveTo(start.x,start.y);}});
    canvas.addEventListener('pointermove',e=>{if(!drawing)return;const p=point(e);style();if(['line','rect','ellipse'].includes(tool)){ctx.putImageData(before,0,0);ctx.beginPath();if(tool==='line'){ctx.moveTo(start.x,start.y);ctx.lineTo(p.x,p.y);}if(tool==='rect')ctx.rect(start.x,start.y,p.x-start.x,p.y-start.y);if(tool==='ellipse')ctx.ellipse((start.x+p.x)/2,(start.y+p.y)/2,Math.max(.5,Math.abs(p.x-start.x)/2),Math.max(.5,Math.abs(p.y-start.y)/2),0,0,Math.PI*2);ctx.stroke();}else{ctx.lineTo(p.x,p.y);ctx.stroke();ctx.beginPath();ctx.moveTo(p.x,p.y);}});
    const end=e=>{if(!drawing)return;drawing=false;if(e.type==='pointercancel'){ctx.putImageData(before,0,0);}else remember(before);if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);};canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',end);
    function setZoom(value){zoom=Math.max(0,Math.min(200,value));canvas.style.width=zoom?`${canvas.width*zoom/100}px`:'';canvas.classList.toggle('paint-zoomed',zoom>0);}
    win.content.addEventListener('click',e=>{
      const selected=e.target.closest('[data-paint-tool]');if(selected){tool=selected.dataset.paintTool;$$('[data-paint-tool]',win.content).forEach(b=>b.setAttribute('aria-pressed',b===selected));controls();}
      const swatch=e.target.closest('[data-color]');if(swatch){color=swatch.dataset.color;$('input[type="color"]',win.content).value=color;$$('[data-color]',win.content).forEach(b=>b.setAttribute('aria-pressed',b===swatch));}
      const view=e.target.closest('[data-paint-view]');if(view){const home=view.dataset.paintView==='home';$('.paint-home-tools',win.content).hidden=!home;$('.paint-view-tools',win.content).hidden=home;$$('[data-paint-view]',win.content).forEach(b=>b.setAttribute('aria-pressed',b===view));}
      const action=e.target.closest('[data-paint]')?.dataset.paint;
      if(action==='undo'&&undo.length){redo.push(snapshot());ctx.putImageData(undo.pop(),0,0);controls();}
      if(action==='redo'&&redo.length){undo.push(snapshot());ctx.putImageData(redo.pop(),0,0);controls();}
      if(action==='clear'){remember(snapshot());ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);}
      if(action==='save')canvas.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob);saveLink(url,'Рисунок.png');setTimeout(()=>URL.revokeObjectURL(url),1000);updateTitle(win,'Рисунок.png — Paint');},'image/png');
      if(action==='zoom-in')setZoom((zoom||100)+25);if(action==='zoom-out')setZoom((zoom||100)-25);if(action==='zoom-fit')setZoom(0);
    });
    $('select',win.content).addEventListener('change',e=>size=Number(e.target.value));$('input[type="color"]',win.content).addEventListener('input',e=>{color=e.target.value;$$('[data-color]',win.content).forEach(b=>b.setAttribute('aria-pressed',b.dataset.color===color));});controls();
  });

  registerApp('tasks',{title:'Диспетчер задач',icon:icons.tasks,width:580,height:425},win=>{
    let selected=null;
    win.content.innerHTML=`<div class="app-menubar"><button data-task-manager="refresh">Обновить</button><button data-open="help">Справка</button></div><div class="task-manager-page"><div class="task-manager-tab">Приложения</div><p>Окна, открытые в этом портфолио</p><table><thead><tr><th>Задача</th><th>Состояние</th></tr></thead><tbody></tbody></table><div class="task-manager-actions"><button data-task-manager="switch" disabled>Переключиться</button><button data-task-manager="end" disabled>Снять задачу</button></div></div><div class="window-status"><span data-task-count></span><span>Приложения сайта</span></div>`;
    function refresh(){const windows=[...state.windows.values()].filter(w=>w.id!==win.id);if(!windows.some(w=>w.id===selected))selected=null;$('tbody',win.content).innerHTML=windows.length?windows.map(w=>`<tr data-manager-id="${w.id}" tabindex="0" class="${selected===w.id?'selected':''}"><td><img src="${w.icon}" alt="">${esc(w.title)}</td><td>${w.minimized?'Свёрнуто':'Работает'}</td></tr>`).join(''):'<tr><td colspan="2">Других открытых приложений нет.</td></tr>';$('[data-task-count]',win.content).textContent=`Приложений: ${windows.length}`;$$('[data-task-manager="switch"],[data-task-manager="end"]',win.content).forEach(b=>b.disabled=!selected);}
    function select(row){selected=row.dataset.managerId;refresh();}
    win.content.addEventListener('click',e=>{const row=e.target.closest('[data-manager-id]');if(row)select(row);const action=e.target.closest('[data-task-manager]')?.dataset.taskManager;if(action==='end'&&selected)closeWindow(selected);if(action==='switch'&&selected)focusWindow(selected,true);if(action)refresh();});
    win.content.addEventListener('dblclick',e=>{const row=e.target.closest('[data-manager-id]');if(row)focusWindow(row.dataset.managerId,true);});
    win.content.addEventListener('keydown',e=>{const row=e.target.closest('[data-manager-id]');if(row&&(e.key==='Enter'||e.key===' ')){e.preventDefault();select(row);}});
    const interval=setInterval(refresh,1200);win.dispose=()=>clearInterval(interval);refresh();
  });

  window.installPortfolioStudio?.({...api,projectInfo,downloadEntry});
  const recruiterEntry={name:'Для работодателя',app:'recruiter',icon:icons.user,type:'Сведения о пользователе'};
  const browserEntry={name:'Internet Explorer',app:'browser',icon:icons.browser,type:'Приложение'};
  const paintEntry={name:'Paint',app:'paint',icon:icons.paint,type:'Приложение'};
  desktopEntries.splice(3,0,recruiterEntry,browserEntry,paintEntry);
  folders.root.items.unshift(recruiterEntry);
  folders.projects.items[2]={...folders.projects.items[2],name:'Портфолио Windows 7',icon:icons.windows};
  folders.projects.items.push(paintEntry,browserEntry);
  startEntries.unshift(browserEntry,recruiterEntry);startEntries.push(paintEntry,{name:'Диспетчер задач',app:'tasks',icon:icons.tasks},{name:'Персонализация',app:'settings',icon:icons.settings});

  // "All programs" is a real grouped list rather than a decorative link.
  const allPrograms=$('.all-programs');allPrograms.setAttribute('role','button');allPrograms.tabIndex=0;allPrograms.setAttribute('aria-expanded','false');let all=false;
  allPrograms.addEventListener('click',e=>{e.stopImmediatePropagation();all=!all;allPrograms.setAttribute('aria-expanded',String(all));allPrograms.innerHTML=`<span>${all?'◀':'▶'}</span>${all?'Назад':'Все программы'}`;$('#start-search').value='';renderStart();},true);
  allPrograms.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();allPrograms.click();}});
  state.renderStartOverride=query=>{if(query||!all)return false;const groups=[['Портфолио',['recruiter','viewer','bug','cost','resume','contacts','site']],['Стандартные',['browser','paint','about','calculator']],['Служебные',['tasks','settings','help']]];$('#start-program-list').innerHTML=groups.map(([name,apps])=>`<div class="start-group-title">${name}</div>${apps.map(app=>`<button class="start-program compact" data-open="${app}"><img src="${appInfo[app].icon}" alt=""><span>${esc(app==='about'?'Блокнот':app==='recruiter'?'Для работодателя':appInfo[app].title)}</span></button>`).join('')}`).join('');$('#start-no-results').hidden=true;return true;};
  const pinned=document.createElement('button');pinned.dataset.open='browser';pinned.title='Internet Explorer';pinned.setAttribute('aria-label','Internet Explorer');pinned.innerHTML=`<img src="${icons.browser}" alt="">`;$('.pinned-apps').prepend(pinned);
  $('#taskbar').addEventListener('contextmenu',e=>{e.preventDefault();closeMenus();contextEntry={name:'Диспетчер задач',app:'tasks',icon:icons.tasks};fileMenu.innerHTML='<button role="menuitem" data-file-command="open">Запустить диспетчер задач</button>';fileMenu.hidden=false;fileMenu.style.left=`${Math.max(4,Math.min(e.clientX,innerWidth-240))}px`;fileMenu.style.top=`${innerHeight-fileMenu.offsetHeight-50}px`;$('button',fileMenu).focus();});
  const employer=document.createElement('button');employer.className='quick-employer';employer.textContent='Для работодателя';employer.addEventListener('click',()=>api.launch({app:'recruiter'}));$('.quick-resume').before(employer);
  window.installPortfolioSystem?.(api);
};
