import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const binary=path.join(root,'node_modules/@esbuild/win32-x64/esbuild.exe');
execFileSync(binary,['viewer-engine.js','--bundle','--format=esm','--platform=browser','--target=es2022','--minify','--legal-comments=eof','--outfile=viewer-runtime.js'],{cwd:root,stdio:'inherit'});
